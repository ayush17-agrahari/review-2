document.addEventListener("DOMContentLoaded", function () {
    // Login Form Validation
    const loginForm = document.getElementById("loginForm");
    loginForm.addEventListener("submit", function (event) {
      let valid = true;
      const email = document.getElementById("email");
      const password = document.getElementById("password");
      
      // Email validation
      if (!email.value.match(/^[\w-]+(\.[\w-]+)*@([\w-]+\.)+[a-zA-Z]{2,7}$/)) {
        document.getElementById("emailError").textContent = "Please enter a valid email address.";
        valid = false;
      } else {
        document.getElementById("emailError").textContent = "";
      }
  
      // Password validation
      if (password.value.length < 6) {
        document.getElementById("passwordError").textContent = "Password must be at least 6 characters.";
        valid = false;
      } else {
        document.getElementById("passwordError").textContent = "";
      }
  
      if (!valid) {
        event.preventDefault();
      }
    });
  
    // Register Form Validation
    const registerForm = document.getElementById("registerForm");
    registerForm.addEventListener("submit", function (event) {
      let valid = true;
      const email = document.getElementById("email");
      const password = document.getElementById("password");
      const confirmPassword = document.getElementById("confirmPassword");
  
      // Email validation
      if (!email.value.match(/^[\w-]+(\.[\w-]+)*@([\w-]+\.)+[a-zA-Z]{2,7}$/)) {
        document.getElementById("emailError").textContent = "Please enter a valid email address.";
        valid = false;
      } else {
        document.getElementById("emailError").textContent = "";
      }
  
      // Password validation
      if (password.value.length < 6) {
        document.getElementById("passwordError").textContent = "Password must be at least 6 characters.";
        valid = false;
      } else {
        document.getElementById("passwordError").textContent = "";
      }
  
      // Confirm password check
      if (password.value !== confirmPassword.value) {
        document.getElementById("confirmPasswordError").textContent = "Passwords do not match.";
        valid = false;
      } else {
        document.getElementById("confirmPasswordError").textContent = "";
      }
  
      if (!valid) {
        event.preventDefault();
      }
    });
  });
  