// Import necessary packages
import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.util.*;

@WebServlet("/QuizServlet")
public class QuizServlet extends HttpServlet {

    // A sample list of questions
    private List<Question> questions;

    @Override
    public void init() throws ServletException {
        questions = new ArrayList<>();
        questions.add(new Question("What is the capital of France?", "Paris", Arrays.asList("Paris", "London", "Berlin", "Madrid")));
        questions.add(new Question("Which programming language is platform-independent?", "Java", Arrays.asList("C", "Java", "Python", "JavaScript")));
        questions.add(new Question("What is 2 + 2?", "4", Arrays.asList("3", "4", "5", "6")));
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Pass the questions to the JSP
        request.setAttribute("questions", questions);
        RequestDispatcher dispatcher = request.getRequestDispatcher("quiz.jsp");
        dispatcher.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int score = 0;

        // Check user answers
        for (int i = 0; i < questions.size(); i++) {
            String userAnswer = request.getParameter("question" + i);
            if (questions.get(i).getCorrectAnswer().equals(userAnswer)) {
                score++;
            }
        }

        // Pass score to result page
        request.setAttribute("score", score);
        request.setAttribute("total", questions.size());
        RequestDispatcher dispatcher = request.getRequestDispatcher("result.jsp");
        dispatcher.forward(request, response);
    }

    // Inner class for a question object
    private static class Question {
        private String question;
        private String correctAnswer;
        private List<String> options;

        public Question(String question, String correctAnswer, List<String> options) {
            this.question = question;
            this.correctAnswer = correctAnswer;
            this.options = options;
        }

        public String getQuestion() {
            return question;
        }

        public String getCorrectAnswer() {
            return correctAnswer;
        }

        public List<String> getOptions() {
            return options;
        }
    }
}
